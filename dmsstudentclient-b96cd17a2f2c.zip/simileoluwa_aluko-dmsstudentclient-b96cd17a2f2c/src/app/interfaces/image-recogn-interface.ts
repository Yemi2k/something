export interface ImageRecognInterface {
    message : string;
    predictionResult : Array<any>
}
