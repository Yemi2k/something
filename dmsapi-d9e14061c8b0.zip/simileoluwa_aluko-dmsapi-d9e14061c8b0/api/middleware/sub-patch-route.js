const axios = require('axios')
const utils = require('../services/utils')
const accountUrl = utils.accountUrl
const waecUrl = utils.waecUrl
const jambUrl = utils.jambUrl

module.exports.subPatchRoutes = (req, res, next)=>{
    let regNumber = req.body.regNumber

    if (req.files['studentPassportPhoto']) {
        let studentPassportPhoto = req.files['studentPassportPhoto'][0].public_id  
        let request = [{
            propertyName : 'studentAvatar',
            value : studentPassportPhoto
        }]
        axios({
            method : 'patch',
            url : `${accountUrl}${regNumber}`,
            data : request
        })
        .then( response => {
            console.log(`student avatar for ${regNumber} updated`)
        })
        .catch(error => {
            console.log(error)
        })
    }
    next()
}