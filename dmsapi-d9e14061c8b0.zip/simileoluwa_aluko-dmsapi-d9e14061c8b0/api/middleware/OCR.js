const axios = require('axios')
const ocrResultProcessor = require('../services/ocrResultProcessor')
const utils = require('../services/utils')
const waecUrl = utils.waecUrl
const jambUrl = utils.jambUrl
const cvUrl = utils.cv_url
const DTD = 'DOCUMENT_TEXT_DETECTION'
const TD = 'TEXT_DETECTION'
const baseCloudinaryUrl = utils.baseCloudinaryUrl

module.exports = (req, res, next) => {
    try {
        const studentRegNumber = req.body.regNumber
        const jambResultImageUrl = req.files['jambResultImage'][0].public_id
        const oLevelResultImageUrl = req.files['oLevelResult'][0].public_id

        processFile(oLevelResultImageUrl, jambResultImageUrl)
            .then(response => {
                postWaecResult(response.waec, oLevelResultImageUrl, studentRegNumber)
                return response.jamb
            })
            .then(processedJambResult => {
                postJambResult(processedJambResult, jambResultImageUrl, studentRegNumber)
                next()                
            })
            .catch(error => {
                console.log(error)
            })
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            message: 'error performing ocr'
        })
    }

}

function processFile(oLevelResultImageUrl, JambResultImageUrl) {
    return new Promise((resolve, reject) => {
        let oLevelOCRDataDTD = ''
        let oLevelOCRDataTD = ''
        let jambOCRDataDTD = ''
        let processedJambResult = ''
        let processedWaecResult = ''

        sendFileToCloudVision(oLevelResultImageUrl).then(response => {
                oLevelOCRDataDTD = response
                return sendFileToCloudVisionTD(oLevelResultImageUrl)
            })
            .then(response => {
                oLevelOCRDataTD = response
                processedWaecResult = ocrResultProcessor.processWaecResult(oLevelOCRDataDTD, oLevelOCRDataTD)
                return sendFileToCloudVision(JambResultImageUrl)
            })
            .then(response => {
                jambOCRDataDTD = response
                processedJambResult = ocrResultProcessor.processJambResult(jambOCRDataDTD)
                let resolveParams = {
                    jamb: processedJambResult,
                    waec: processedWaecResult
                }
                resolve(resolveParams)
            })
            .catch(error => {
                console.log(error)
                reject(error)
            })
    })
}

function sendFileToCloudVision(contentUrl) {
    return new Promise((resolve, reject) => {
        let request = {
            requests: [{
                image: {
                    source: {
                        imageUri: baseCloudinaryUrl + contentUrl
                    }
                },
                features: [{
                    type: DTD,
                    maxResults: 200
                }]
            }]
        };
        axios({
                method: 'post',
                url: cvUrl,
                data: request,
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                // console.log(response)
                // console.log('response', response.data.responses[0].fullTextAnnotation.text)
                resolve(response.data.responses[0].fullTextAnnotation.text)
            })
            .catch(error => {
                reject(error)
            })
    })
}

function sendFileToCloudVisionTD(contentUrl) {
    return new Promise((resolve, reject) => {
        let request = {
            requests: [{
                image: {
                    source: {
                        imageUri: baseCloudinaryUrl + contentUrl
                    }
                },
                features: [{
                    type: TD
                }]
            }]
        }
        axios({
                method: 'post',
                url: cvUrl,
                data: request,
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => {
                // console.log(response)
                // console.log(response.data.responses[0].fullTextAnnotation.text)  
                resolve(response.data.responses[0].fullTextAnnotation.text)
            })
            .catch(error => {
                reject(error)
            })
    })
}

function postWaecResult(data, oLevelResultImageUrl, studentRegNumber) {
    let request = {
        name: data[2].candidateName,
        studentRegNumber: studentRegNumber,
        examNumber: data[2].examinationNumber,
        examination: data[2].examination,
        centre: data[2].centre,
        takenSubject: data[0],
        grades: data[1],
        image: oLevelResultImageUrl
    }
    axios({
            method: 'post',
            url: waecUrl,
            data: request
        })
        .then(response => {
            console.log('post waec successful')
        })
        .catch(error => {
            console.log(error)
        })
}

function postJambResult(data, jambResultImageUrl, studentRegNumber) {
    let request = {
        studentRegNumber: studentRegNumber,
        personalDetails: data[2],
        result: data[0],
        choices: data[1],
        image: jambResultImageUrl
    }
    axios({
            method: 'post',
            url: jambUrl,
            data: request
        })
        .then(response => {
            console.log('post jamb successful')
        })
        .catch(error => {
            console.log(error)
        })
}