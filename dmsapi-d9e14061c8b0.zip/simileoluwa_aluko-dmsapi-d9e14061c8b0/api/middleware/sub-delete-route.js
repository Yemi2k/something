const axios = require('axios')
const utils = require('../services/utils')
const waecUrl = utils.waecUrl
const jambUrl = utils.jambUrl
const studentUrl = utils.studentUrl

module.exports = (req, res, next) => {
    let regNumber = req.params.registrationNumber

    axios({
        method : 'delete',
        url :  `${waecUrl}${regNumber}`
    }).then(response => {
        message : `waec data for ${regNumber} deleted`
    }).catch( error => {
        console.log(error)
    })

    axios({
        method : 'delete',
        url :  `${jambUrl}${regNumber}`
    }).then(response => {
        message : `jamb data for ${regNumber} deleted`
    }).catch( error => {
        console.log(error)
    })

    axios({
        method : 'delete',
        url :  `${studentUrl}${regNumber}`
    }).then(response => {
        message : `student data for ${regNumber} deleted`
    }).catch( error => {
        console.log(error)
    })

    next()
}