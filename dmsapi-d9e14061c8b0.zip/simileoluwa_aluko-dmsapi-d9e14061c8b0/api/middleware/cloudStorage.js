const multer = require('multer')
const cloudinary = require('cloudinary')
const cloudinaryStorage = require('multer-storage-cloudinary');
const cloudinaryConfig = require('../services/utils')

cloudinary.config(cloudinaryConfig.cloudinaryConfig)

const cloudStorage = cloudinaryStorage({
    cloudinary : cloudinary,
    folder : 'dms/students'
})

/** storage object */
const upload = multer({
    storage: cloudStorage
})

module.exports = upload.fields([{
    name: 'studentPassportPhoto',
    maxCount: 1
},
{
    name: 'fathersPassportPhoto',
    maxCount: 1
},
{
    name: 'mothersPassportPhoto',
    maxCount: 1
},
{
    name: 'jambResultImage',
    maxCount: 1
},
{
    name: 'waecResultImage',
    maxCount: 1
},
{
    name: 'oLevelResult',
    maxCount: 1
},
{
    name: 'recommendationLetter',
    maxCount: 1
},
{
    name: 'jambAdmissionLetter',
    maxCount: 1
},
{
    name: 'birthCertificate',
    maxCount: 1
}
])