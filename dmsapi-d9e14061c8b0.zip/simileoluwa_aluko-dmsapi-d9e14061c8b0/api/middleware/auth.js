const jwt = require('jsonwebtoken')
const jwtSecretString = require('../services/utils').jwtSecretString

module.exports = (req, res, next) => {
    try {
        const token = req.headers.authorization.split(" ")[1]
        const decoded = jwt.verify(token, jwtSecretString)
        req.userData = decoded
        next()
    } catch (error) {
        return res.status(401).json({ // 401 - unauthorised
            message : 'auth failed'
        })
    }
}