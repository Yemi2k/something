let baseUrl = 'http://localhost:8000/'
module.exports = {
    defaultError : (error) => {
        return {
            resStatus : 500,
            message : error
        }
    },
    jwtSecretString : 'secret',
    port : 8000,
    cv_url : //google cloud vision url,
    cloud_name : //cloudinary name,
    api_key ://cloudinary api key,
    api_secret : // cloudinary api secret,
    waecUrl : `${baseUrl}waec/`,
    jambUrl : `${baseUrl}jamb/`,
    accountUrl : `${baseUrl}accounts/`,
    studentUrl : `${baseUrl}students/`,
    baseCloudinaryUrl : //cloudinary url
}
module.exports.cloudinaryConfig = {
    cloud_name : //cloudinary name,
    api_key ://cloudinary api key,
    api_secret : // cloudinary api secret,
}