const OCR = require('../middleware/OCR')
const waecSubjects = ['ENGLISH LANGUAGE','GENERAL MATHEMATICS','CATERING CRAFT PRACTICE', 'MATHEMATICS', 'FURTHER MATHEMATICS', 'PHYSICS', 'CHEMISTRY', 'BIOLOGY', 'GEOGRAPHY', 'LITERATURE IN ENGLISH', 'ECONOMICS', 'COMMERCE', 'FINANCIAL ACCOUNTING', 'GOVERNMENT', 'CHRISTIAN RELIGIOUS STUDIES', 'AGRICULTURAL SCIENCE', 'ISLAMIC STUDIES', 'HISTORY', 'FRENCH', 'HAUSA LANGUAGE', 'IGBO LANGUAGE', 'YORUBA LANGUAGE', 'MUSIC', 'FINE ARTS', 'BOOK KEEPING', 'DATA PROCESSING', 'FOODS & NUTRITION', 'MARKETING', 'CIVIC EDUCATION', 'DYEING & BLEACHING', 'ANIMAL HUSBANDRY', 'OFFICE PRACTICE', 'COMPUTER STUDIES', 'TECHNICAL DRAWING', 'RADIO, TV & ELECTRONICS WORKS', 'ELECTR INSTAL & MAINTEN WORKS', 'PAINTING & DECORATING', 'FISHERIES', 'PHOTOGRAPHY', 'CATERING CRAFT PRACTICE' ]
const gradesExtra = ['ABS']

module.exports.processWaecResult = (documentTextDetectionDescription, textDetectionDescription) => {
  let examinationNumber = ''
  let candidateName = ''
  let examination = ''
  let centre = ''
  let takenSubject = []
  let grades = []
  let waecPersonalDetails = {}

  tdd = textDetectionDescription
  dtdd = documentTextDetectionDescription
  let Centre = 'Centre'
  let subjGrades = 'Subject Grades'

  //if extracted texts includes centre
  if (dtdd.includes(Centre)) {
    let candidateInfo = dtdd.substring(dtdd.indexOf(Centre) + 6, dtdd.indexOf(subjGrades)).trim()

    let candidateInfoArray = candidateInfo.replace(/(\r\n|\n|\r)/gm, "-").split("-")
    waecPersonalDetails['examinationNumber'] = candidateInfoArray[0]
    waecPersonalDetails['candidateName'] = candidateInfoArray[1]
    waecPersonalDetails['examination'] = candidateInfoArray[2]
    waecPersonalDetails['centre'] = candidateInfoArray[3]
  }

  // if extracted texts includes subject grades
  if (dtdd.includes(subjGrades)) {
    let subjectGrades = dtdd.substring(dtdd.indexOf(subjGrades) + 14).trim()
    let subjectGradesArray = subjectGrades.replace(/(\r\n|\n|\r)/gm, "-").split("-")
    subjectGradesArray.forEach(subjGradesElement => {
      waecSubjects.forEach(waecSubject => {
        if (subjGradesElement == waecSubject) {
          takenSubject.push(waecSubject)
        }
      })
    })
  }

  //perform extraction of grades
  let tdArray = tdd.replace(/(\r\n|\n|\r)/gm, "-").split("-")
  let gradeRegex1 = new RegExp("^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+$")
  let gradeRegex2 = new RegExp("^(?=.*?\\d.*\\d)[A-Z0-9]{1,2}$")
  let gradeRegex3 = new RegExp("^(?=.*[A-Z])(?=.*[a-z])[A-Za-z]+$")
  tdArray.forEach(tdArrayElement => {
    if (tdArrayElement.length == 2 &&
      (gradeRegex1.test(tdArrayElement) || gradeRegex2.test(tdArrayElement) ||
        gradeRegex3.test(tdArrayElement))) {
      grades.push(tdArrayElement)
    }
  })

  return [takenSubject, grades, waecPersonalDetails]
}

/** PROCESS JAMB OCR RESPONSE */
module.exports.processJambResult = (jambOCRResultDTD) => {
  let personalDetails = 'PERSONAL DETAILS'
  let examResult = 'EXAMINATION RESULT'
  let note = 'NOTE:'
  let choices = 'CHOICES'
  let forbiddenValuesInPersonalDetails = ['Surname:', 'First Name', 'Middle Name:', 'Gender:', 'State of Origin:', 'State Of Origin:, Local Govt. Area:']
  let jambResult = {}
  let jambchoices = {}
  let jambPersonalDetails = {}
  /** GET PERSONAL DETAILS */
  if (jambOCRResultDTD.includes(personalDetails)) {
    let personalDetailsSection = jambOCRResultDTD.substring(jambOCRResultDTD.indexOf(personalDetails) + 16, jambOCRResultDTD.indexOf(examResult)).trim()
    let personalDetailsArray = personalDetailsSection.replace(/(\r\n|\n|\r)/gm, "-").split("-")

    if (personalDetailsArray.indexOf('Examination Centre:') == 8 || personalDetailsArray.indexOf('Examination Centre ') == 8) {
      jambPersonalDetails['Surname'] = personalDetailsArray[9]
      jambPersonalDetails['First Name'] = personalDetailsArray[10]
      jambPersonalDetails['Middle Name'] = personalDetailsArray[11]
      jambPersonalDetails['Gender'] = personalDetailsArray[12]
      jambPersonalDetails['State'] = personalDetailsArray[13]
      jambPersonalDetails['Local Govt Area'] = personalDetailsArray[14]
      jambPersonalDetails['Registration Number'] = personalDetailsArray[15]
      jambPersonalDetails['Examination Number'] = personalDetailsArray[16]
      jambPersonalDetails['Examination Center'] = personalDetailsArray[17]
    } else {
      jambPersonalDetails['Surname'] = getPersonalDetail(personalDetailsArray, "Surname:")
      jambPersonalDetails['First Name'] = getPersonalDetail(personalDetailsArray, "First Name:")
      jambPersonalDetails['Middle Name'] = getPersonalDetail(personalDetailsArray, "Middle Name:")
      jambPersonalDetails['Gender'] = getPersonalDetail(personalDetailsArray, "Gender:")
      jambPersonalDetails['State'] = getPersonalDetail(personalDetailsArray, "State Of Origin:")
      jambPersonalDetails['Local Govt Area'] = getPersonalDetail(personalDetailsArray, "Local Govt. Area:")
      jambPersonalDetails['Registration Number'] = filterFromArrayValue(personalDetailsArray, "Registration Number:")
      jambPersonalDetails['Examination Number'] = filterFromArrayValue(personalDetailsArray, "Examination Number:")
      jambPersonalDetails['Examination Center'] = filterFromArrayValue(personalDetailsArray, "Examination Centre:")
    }
  }

  /** GET JAMB RESULT GRADES */
  if (jambOCRResultDTD.includes(examResult)) {
    let jambOCRResponseArray = jambOCRResultDTD.replace(/(\r\n|\n|\r)/gm, "-").split("-")
    let resultArray = []
    let formattedResultArray = []
    jambOCRResponseArray.forEach(element => {
      if (element.includes(' = ')) {
        resultArray.push(element)
      }
    })
    resultArray.forEach(element => {
      let elementArray = element.split(';')
      if (elementArray[1]) {
        formattedResultArray.push(elementArray[0].trim())
        formattedResultArray.push(elementArray[1].trim())
      } else {
        formattedResultArray.push(elementArray[0].trim())
      }
    })

    formattedResultArray.forEach(element => {
      let elementArray = element.split(' = ')
      jambResult[elementArray[0]] = elementArray[1]
    })
  }

  /** GET UNI CHOICES */
  if (jambOCRResultDTD.includes(choices)) {
    let jambChoicesSection = jambOCRResultDTD.substring(jambOCRResultDTD.indexOf(choices) + 7, jambOCRResultDTD.indexOf(note)).trim()
    let examResultArray = jambChoicesSection.replace(/(\r\n|\n|\r)/gm, "-").split("-")
    let institutionArray = []
    let courseArray = []
    examResultArray.forEach(element => {
      if (element.includes('Institution')) {
        institutionArray.push(element)
      }
    })
    examResultArray.forEach(element => {
      if (element.includes('Course')) {
        courseArray.push(element)
      }
    })

    jambchoices['FirstChoice'] = {
      Institution: institutionArray[1]
    } //, Course : courseArray[0]
    jambchoices['SecondChoice'] = {
      Institution: institutionArray[2]
    } //, Course : courseArray[2]
    jambchoices['ThirdChoice'] = {
      Institution: institutionArray[0]
    } //, Course : courseArray[1]
    jambchoices['FourthChoice'] = {
      Institution: institutionArray[3]
    } //, Course : courseArray[3]
  }


  /** UTILITY FUNCTIONS */
  function getPersonalDetail(array, bookmark) {
    let index = array.indexOf(bookmark) + 1
    let returnValue = array[index]
    if (index == 0) {
      returnValue = ''
    }
    forbiddenValuesInPersonalDetails.forEach(element => {
      if (array[index] == element) {
        returnValue = ''
      }
    })
    return returnValue
  }

  function filterFromArrayValue(array, value) {
    let returnValue = ''
    array.forEach(element => {
      if (element.includes(value)) {
        returnValue = element.substring(element.indexOf(':') + 1)
      }
    })
    return returnValue
  }
  return [jambResult, jambchoices, jambPersonalDetails]
}