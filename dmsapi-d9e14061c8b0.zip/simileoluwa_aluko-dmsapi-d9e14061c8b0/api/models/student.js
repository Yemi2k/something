const mongoose = require('mongoose')

const studentSchema = mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    otherNames: {
        type: String,
        required: true
    },
    Email: {
        type: String,
        required: true,
        unique : true, 
        sparse : true
    },
    dateOfBirth: {
        type: String,
        required: true
    },
    placeOfBirth: {
        type: String,
        required: true
    },
    countryOfOrigin: {
        type: String,
        required: true
    },
    stateOfOrigin: {
        type: String,
        required: true
    },
    localGovtArea: {
        type: String,
        required: true
    },
    Address: {
        type: String,
        required: true
    },
    phoneNumber: {
        type: String,
        required: true
    },
    studentPassportPhoto: {
        type: String,
        required: true
    },
    regNumber : {
        type : String,
        required : true,
        unique : true, 
        sparse : true
    },
    fathersFirstName: {
        type: String,
        required: true
    },
    fathersSurname: {
        type: String,
        required: true
    },
    fathersEmail: {
        type: String,
        required: true
    },
    fathersPhoneNumberOne: {
        type: String,
        required: true
    },
    fathersPhoneNumberTwo: {
        type: String,
        required: true
    },
    fathersAddress: {
        type: String,
        required: true
    },
    fathersStateOfOrigin: {
        type: String,
        required: true
    },
    fathersPassportPhoto: {
        type: String,
        required: true
    },
    fathersOccupation: {
        type: String,
        required: true
    },
    mothersFirstName: {
        type: String,
        required: true
    },
    mothersSurname: {
        type: String,
        required: true
    },
    mothersEmail: {
        type: String,
        required: true
    },
    mothersPhoneNumberOne: {
        type: String,
        required: true
    },
    mothersPhoneNumberTwo: {
        type: String,
        required: true
    },
    mothersAddress: {
        type: String,
        required: true
    },
    mothersStateOfOrigin: {
        type: String,
        required: true
    },
    mothersPassportPhoto: {
        type: String,
        required: true
    },
    mothersOccupation: {
        type: String,
        required: true
    },
    //documents
    jambResultImage: {
        type: String,
        required: true
    },
    waecResultImage: {
        type: String
    },
    oLevelResult : {
        type : String,
        required : true
    },
    oLevelResultType : {
        type : String,
        required : true
    },
    recommendationLetter: {
        type: String,
        required: true
    },
    jambAdmissionLetter: {
        type: String,
        required: true
    },
    birthCertificate: {
        type: String,
        required: true
    }
})

module.exports = mongoose.model('Student', studentSchema)