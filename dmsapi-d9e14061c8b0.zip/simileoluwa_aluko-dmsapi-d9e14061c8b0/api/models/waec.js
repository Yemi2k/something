const mongoose = require('mongoose')

const waecSchema = mongoose.Schema({
    _id : mongoose.Schema.Types.ObjectId,
    name : {type : String, required : true},
    studentRegNumber : {type : String, required : true, unique : true, sparse : true},
    examNumber : {type : String, required : true},
    examination : {type : String, required : true},
    centre : {type : String},
    takenSubject : {type : Array},
    grades : {type : Array},
    image : {type : String}
    //subjects -- still kept for future purposes
    // englishLanguage : {type : String},
    // generalMathematics : {type : String},
    // furtherMathematics : {type : String},
    // physics : {type : String},
    // chemistry : {type : String},
    // biology : {type : String},
    // geography : {type : String},
    // literatureInEnglish : {type : String},
    // economics : {type : String},
    // commerce : {type : String},
    // financialAccounting : {type : String},
    // government : {type : String},
    // christianReligiousStudies : {type : String},
    // agricScience : {type : String},
    // IslamicReligiousStudies: {type : String},
    // history : {type : String},
    // french : {type : String},
    // hausa : {type : String},
    // igbo : {type : String},
    // yoruba : {type : String},
    // music : {type : String},
    // fineArts : {type : String},
    // civicEducation : {type : String},
    // bookKeeping : {type : String},
    // dataProcessing : {type : String},
    // foodsAndNutrition : {type : String},
    // marketing : {type : String},
    // dyeingAndBleaching : {type : String},
    // animalHusbandry : {type : String},
    // officePractice : {type : String},
    // computerStudies : {type : String},
    // technicalDrawing : {type : String},
    // radioTVElectronicsWorks : {type:String}
})

module.exports = mongoose.model('Waec', waecSchema)