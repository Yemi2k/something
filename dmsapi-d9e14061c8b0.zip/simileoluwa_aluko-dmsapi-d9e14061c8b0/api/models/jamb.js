const mongoose = require('mongoose')

const jambSchema = mongoose.Schema({
    _id : mongoose.Schema.Types.ObjectId,
    studentRegNumber : {type : String, required : true, unique : true, sparse : true},
    personalDetails : {type:Object, required : true},
    result : {type : Object, required : true},
    choices : {type : Object, required : true},
    image : {type : String}
    // surname : {type : String, required : true },
    // firstName : {type : String, required : true },
    // otherName : {type : String, required : true }, // or middle name
    // studentRegNumber : {type : String, required : true},
    // gender : {type : String, required : true },
    // stateOfOrigin : {type : String, required : true },
    // localGovtArea : {type : String, required : true }, //or L.G.A.
    // dateOfBirth : {type : String},
    // registrationNumber : {type : String, required : true}, 
    // examinationNumber : {type : String, required : true},
    // examinationCentre : {type : String},
    // firstChoice : {type : String, required : true},
    // secondChoice : {type : String, required : true},
    // thirdChoice : {type : String, required : true},
    // fourthChoice : {type : String, required : true},
    // jambResult : {type : Object},
    //subjects
    // useOfEnglish : {type : Number},
    // mathematics : {type : Number},
    // physics : {type : Number},
    // chemistry : {type : Number},
    // biology : {type : Number},
    // geography : {type : Number},
    // literatureInEnglish : {type : Number},
    // economics : {type : Number},
    // commerce : {type : Number},
    // accounts : {type : Number},
    // government : {type : Number},
    // christianReligiousKnowledge : {type : Number},
    // agricScience : {type : Number},
    // IslamicReligiousKnowledge : {type : Number},
    // history : {type : Number},
    // art : {type : Number},
    // french : {type : Number},
    // hausa : {type : Number},
    // igbo : {type : Number},
    // yoruba : {type : Number},
    // music : {type : Number},
    // fineArts : {type : Number}
})

module.exports = mongoose.model('Jamb', jambSchema)