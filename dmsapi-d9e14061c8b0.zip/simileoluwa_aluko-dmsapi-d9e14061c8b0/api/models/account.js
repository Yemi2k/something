const mongoose = require('mongoose')

const accountSchema = mongoose.Schema({
    _id : mongoose.Schema.Types.ObjectId,
    firstName: {type : String},
    lastName : {type : String},
    email : {type : String, required : true, unique : true, sparse : true},
    course : {type : String},
    college : {type : String},
    regNumber : {type : String, unique : true, sparse : true},
    admissionYear : {type : String},
    department : {type : String},
    admissionStatus : {type : String},
    studentAvatar : {type : String },
    informationCompletionStatus : {type : Number},
    password : {type : String, required : true}
    }
)

module.exports = mongoose.model('Account', accountSchema)