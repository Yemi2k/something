const express = require('express')
const router = express.Router()
const Student = require('../models/student')
const mongoose = require('mongoose')
const utils = require('../services/utils')

const portNumber = utils.port
const baseStudentUrl = 'http://localhost:' + portNumber + '/students/'
const defaultError = utils.defaultError

const ocr = require('../middleware/OCR')
const subPatchRoute = require('../middleware/sub-patch-route')
const subPatchRoutes = subPatchRoute.subPatchRoutes
const cloudStorage = require('../middleware/cloudStorage')

/* <-------------------------------------------------POST******----------------------------------------> */

router.post('/', cloudStorage, ocr, subPatchRoutes, (req, res, next) => {

    try {
        let studentPassportPhoto = fathersPassportPhoto = mothersPassportPhoto = jambResultImage = waecResultImage = igcseImage = nabtebImage = necoResultImage = recommendationLetter = jambAdmissionLetter = birthCertificate = 'no file'
        let oLevelResult = req.files['oLevelResult'][0].public_id

        if (req.body.oLevelResultType == 'WAEC') {
            waecResultImage = req.files['oLevelResult'][0].public_id
        } else if (req.body.oLevelResultType == 'NECO') {
            necoResultImage = req.files['oLevelResult'][0].public_id
        } else {
            res.status(500).json({
                message: 'Error processing O level Result Type'
            })
        }

        if (req.files['studentPassportPhoto']) {
            studentPassportPhoto = req.files['studentPassportPhoto'][0].public_id
        }
        if (req.files['fathersPassportPhoto']) {
            fathersPassportPhoto = req.files['fathersPassportPhoto'][0].public_id
        }
        if (req.files['mothersPassportPhoto']) {
            mothersPassportPhoto = req.files['mothersPassportPhoto'][0].public_id
        }
        if (req.files['jambResultImage']) {
            jambResultImage = req.files['jambResultImage'][0].public_id
        }
        if (req.files['recommendationLetter']) {
            recommendationLetter = req.files['recommendationLetter'][0].public_id
        }
        if (req.files['jambAdmissionLetter']) {
            jambAdmissionLetter = req.files['jambAdmissionLetter'][0].public_id
        }
        if (req.files['birthCertificate']) {
            birthCertificate = req.files['birthCertificate'][0].public_id
        }

        const student = new Student({
            _id: new mongoose.Types.ObjectId(),
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            otherNames: req.body.otherNames,
            Email: req.body.Email,
            dateOfBirth: req.body.dateOfBirth,
            placeOfBirth: req.body.placeOfBirth,
            countryOfOrigin: req.body.countryOfOrigin,
            stateOfOrigin: req.body.stateOfOrigin,
            localGovtArea: req.body.localGovtArea,
            Address: req.body.Address,
            phoneNumber: req.body.phoneNumber,
            studentPassportPhoto: studentPassportPhoto,
            regNumber : req.body.regNumber,
            fathersFirstName: req.body.fathersFirstName,
            fathersSurname: req.body.fathersSurname,
            fathersEmail: req.body.fathersEmail,
            fathersPhoneNumberOne: req.body.fathersPhoneNumberOne,
            fathersPhoneNumberTwo: req.body.fathersPhoneNumberTwo,
            fathersAddress: req.body.fathersAddress,
            fathersStateOfOrigin: req.body.fathersStateOfOrigin,
            fathersPassportPhoto: fathersPassportPhoto,
            fathersOccupation: req.body.fathersOccupation,
            mothersFirstName: req.body.mothersFirstName,
            mothersSurname: req.body.mothersSurname,
            mothersEmail: req.body.mothersEmail,
            mothersPhoneNumberOne: req.body.mothersPhoneNumberOne,
            mothersPhoneNumberTwo: req.body.mothersPhoneNumberTwo,
            mothersAddress: req.body.mothersAddress,
            mothersStateOfOrigin: req.body.mothersStateOfOrigin,
            mothersPassportPhoto: mothersPassportPhoto,
            mothersOccupation: req.body.mothersOccupation,
            jambResultImage: jambResultImage,
            waecResultImage: waecResultImage,
            oLevelResult: oLevelResult,
            oLevelResultType: req.body.oLevelResultType,
            necoResultImage: necoResultImage,
            recommendationLetter: recommendationLetter,
            jambAdmissionLetter: jambAdmissionLetter,
            birthCertificate: birthCertificate
        })

        student
            .save()
            .then(result => {
                res.status(201).json({
                    resStatus : 201,
                    message: 'student records created',
                    requests: {
                        type: 'GET',
                    }
                })
            })
            .catch(error => {
                res.status(500).json(defaultError(error))
            })
    } catch (error) {
        console.log(error)
    }
})

/* <-------------------------------------------------GET_ALL******----------------------------------------> */


/* GET ROUTE - ALL STUDENTS RECORDS*/
router.get('/', (req, res, next) => {
    Student
        .find()
        .select('-__v -_id')
        .exec()
        .then(docs => {
            const response = {
                resStatus : 200,
                count: docs.length,
                StudentRecords: docs.map(doc => {
                    return {
                        record: doc,
                        requests: {
                            type: 'GET',
                            url: baseStudentUrl + doc.regNumber
                        }
                    }
                })
            }
            res.status(200).json(response)
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})


/* <-------------------------------------------------GET******----------------------------------------> */

/* GET ROUTE - SINGLE STUDENT RECORD */
router.get('/:regNumber', (req, res, next) => {
    const regNumber = req.params.regNumber
    Student
        .findById(regNumber)
        .select('-__v -_id')
        .exec()
        .then(doc => {
            if (doc) {
                res.status(200).json({
                    resStatus : 200,
                    student: doc,
                    requests: 'GET',
                    url: baseStudentUrl
                })
            } else {
                res.status(404).json({
                    resStatus : 404,
                    message: 'no entry found'
                })
            }
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------DELETE******----------------------------------------> */


/* DELETE ROUTE */
router.delete('/:regNumber', (req, res, next) => {
    const regNumber = req.params.regNumber

    Student
        .remove({
            regNumber: regNumber
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'record deleted',
                result: result,
                request: {
                    type: 'GET',
                    url: baseStudentUrl
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------PATCH******----------------------------------------> */


/* PATCH ROUTE */
router.patch('/:regNumber', (req, res, next) => {
    const regNumber = req.params.regNumber

    const updateTo = {}

    for (const entry of req.body) {
        updateTo[entry.propertyName] = entry.value
    }

    Student
        .update({
            _id: regNumber
        }, {
            $set: updateTo
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'record updated',
                result: result,
                requests: {
                    type: 'GET',
                    url: baseStudentUrl + regNumber
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError())
        })
})

/* <-------------------------------------------------******----------------------------------------> */

module.exports = router