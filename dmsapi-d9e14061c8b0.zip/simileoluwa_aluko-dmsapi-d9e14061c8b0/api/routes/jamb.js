const express = require('express')
const router = express.Router()
const Jamb = require('../models/jamb')
const mongoose = require('mongoose')
const utils = require('../services/utils')
const portNumber = utils.port
const baseJambUrl = 'http://localhost:' + portNumber + '/jamb/'
const defaultError = utils.defaultError
const auth = require('../middleware/auth')


/* <-------------------------------------------------POST******----------------------------------------> */


/* POST ROUTE */
router.post('/', (req, res, next) => {

    const jamb = new Jamb({
        _id: new mongoose.Types.ObjectId(),
        studentRegNumber : req.body.studentRegNumber,
        personalDetails : req.body.personalDetails,
        result : req.body.result,
        choices : req.body.choices,
        image : req.body.image
        // surname: req.body.surname,
        // firstName: req.body.firstName, // or centreNumber
        // otherName: req.body.otherName,
        // gender: req.body.gender,
        // stateOfOrigin: req.body.stateOfOrigin,
        // localGovtArea : req.body.localGovtArea,
        // dateOfBirth : req.body.dateOfBirth,
        // registrationNumber : req.body.registrationNumber,
        // examinationNumber : req.body.examinationNumber,
        // examinationCentre : req.body.examinationCentre,
        // firstChoice : req.body.firstChoice,
        // secondChoice : req.body.secondChoice,
        // thirdChoice : req.body.thirdChoice,
        // fourthChoice : req.body.fourthChoice,
        //subjects
        // useOfEnglish: req.body.useOfEnglish,
        // mathematics: req.body.mathematics,
        // physics: req.body.physics,
        // chemistry: req.body.chemistry,
        // biology: req.body.biology,
        // geography: req.body.geography,
        // literatureInEnglish: req.body.literatureInEnglish,
        // economics: req.body.economics,
        // commerce: req.body.commerce,
        // accounts: req.body.accounts,
        // government: req.body.government,
        // christianReligiousStudies: req.body.christianReligiousStudies,
        // agricScience: req.body.agricScience,
        // IslamicReligiousStudies: req.body.IslamicReligiousStudies,
        // history: req.body.history,
        // art : req.body.art,
        // french: req.body.french,
        // hausa: req.body.hausa,
        // igbo: req.body.igbo,
        // yoruba: req.body.yoruba,
        // music: req.body.music,
        // fineArts: req.body.fineArts
    })

    jamb
        .save()
        .then(result => {
            res.status(201).json({
                message : 'jamb records created',
                igcseRecord : result,
                requests : {
                    type : 'GET',
                    url : baseJambUrl
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------GET_ALL******----------------------------------------> */


/* GET ROUTE - ALL JAMB RECORDS*/
router.get('/', (req, res, next) => {
    Jamb
        .find()
        .exec()
        .then(docs => {
            const response = {
                count: docs.length,
                JambRecords: docs.map(doc => {
                    return {
                        record: doc,
                        requests: {
                            type: 'GET',
                            url: baseJambUrl + doc.studentRegNumber
                        }
                    }
                })
            }
            res.status(200).json(response)
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})


/* <-------------------------------------------------GET******----------------------------------------> */

/* GET ROUTE - SINGLE JAMB RECORD */
router.get('/:studentRegNumber', (req, res, next) => {
    const studentRegNumber = req.params.studentRegNumber
    Jamb
        .findById(studentRegNumber)
        .exec()
        .then(doc => {
            if (doc) {
                res.status(201).json({
                    jambRecord: doc,
                    requests: 'GET',
                    url: baseJambUrl
                })
            } else {
                res.status(404).json({
                    message: 'no entry found'
                })
            }
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------DELETE******----------------------------------------> */


/* DELETE ROUTE */
router.delete('/:studentRegNumber', (req, res, next) => {
    const studentRegNumber = req.params.studentRegNumber

    Jamb
        .remove({
            studentRegNumber: studentRegNumber
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'record deleted',
                result: result,
                request: {
                    type: 'GET',
                    url: baseJambUrl
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------PATCH******----------------------------------------> */


/* PATCH ROUTE */
router.patch('/:studentRegNumber', (req, res, next) => {
    const studentRegNumber = req.params.studentRegNumber

    const updateTo = {}

    for (const entry of req.body) {
        updateTo[entry.propertyName] = entry.value
    }

    console.log(updateTo)

    Jamb
        .update({
            studentRegNumber: studentRegNumber
        }, {
            $set: updateTo
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'record updated',
                result: result,
                requests: {
                    type: 'GET',
                    url: baseJambUrl + studentRegNumber
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError())
        })
})

/* <-------------------------------------------------******----------------------------------------> */

module.exports = router