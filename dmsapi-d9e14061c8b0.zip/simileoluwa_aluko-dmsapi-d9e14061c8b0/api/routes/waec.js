const express = require('express')
const router = express.Router()
const Waec = require('../models/waec')
const mongoose = require('mongoose')
const utils = require('../services/utils')
const portNumber = utils.port
const baseWaecUrl = 'http://localhost:' + portNumber + '/waec/'
const defaultError = utils.defaultError
const auth = require('../middleware/auth')


/* <-------------------------------------------------POST******----------------------------------------> */


/* POST ROUTE */
router.post('/', (req, res, next) => {
    const waec = new Waec({
        _id: new mongoose.Types.ObjectId(),
        name: req.body.name,
        studentRegNumber : req.body.studentRegNumber,
        examNumber: req.body.examNumber, // or centreNumber
        examination: req.body.examination,
        centre : req.body.centre,
        takenSubject : req.body.takenSubject,
        grades : req.body.grades,
        image : req.body.image
    })

    waec
        .save()
        .then(result => {
            res.status(201).json({
                message : 'waec records created',
                waecRecord : result,
                requests : {
                    type : 'GET',
                    url : baseWaecUrl
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------GET_ALL******----------------------------------------> */


/* GET ROUTE - ALL WAEC RECORDS*/
router.get('/', (req, res, next) => {
    Waec
        .find()
        .exec()
        .then(docs => {
            const response = {
                count: docs.length,
                WaecRecords: docs.map(doc => {
                    return {
                        record: doc,
                        requests: {
                            type: 'GET',
                            url: baseWaecUrl + doc.studentRegNumber
                        }
                    }
                })
            }
            res.status(200).json(response)
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})


/* <-------------------------------------------------GET******----------------------------------------> */

/* GET ROUTE - SINGLE WAEC RECORD */
router.get('/:studentRegNumber',  (req, res, next) => {
    const studentRegNumber = req.params.studentRegNumber
    Waec
        .findById(studentRegNumber)
        .exec()
        .then(doc => {
            if (doc) {
                res.status(201).json({
                    waecRecord: doc,
                    requests: 'GET',
                    url: baseWaecUrl
                })
            } else {
                res.status(404).json({
                    message: 'no entry found'
                })
            }
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------DELETE******----------------------------------------> */


/* DELETE ROUTE */
router.delete('/:studentRegNumber', (req, res, next) => {
    const studentRegNumber = req.params.studentRegNumber

    Waec
        .remove({
            studentRegNumber : studentRegNumber
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'record deleted',
                result: result,
                request: {
                    type: 'GET',
                    url: baseWaecUrl
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------PATCH******----------------------------------------> */


/* PATCH ROUTE */
router.patch('/:studentRegNumber', (req, res, next) => {
    const studentRegNumber = req.params.studentRegNumber

    const updateTo = {}

    for (const entry of req.body) {
        updateTo[entry.propertyName] = entry.value
    }

    console.log(updateTo)

    Waec
        .update({
            studentRegNumber : studentRegNumber
        }, {
            $set: updateTo
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'record updated',
                result: result,
                requests: {
                    type: 'GET',
                    url: baseWaecUrl + studentRegNumber
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------******----------------------------------------> */

module.exports = router