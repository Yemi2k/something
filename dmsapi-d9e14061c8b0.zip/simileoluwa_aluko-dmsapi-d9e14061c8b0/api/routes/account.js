const express = require('express')
const router = express.Router()
const Account = require('../models/account')
const mongoose = require('mongoose')
const multer = require('multer')
const utils = require('../services/utils')
const defaultError = utils.defaultError
const portNumber = utils.port
const cloudinary = require('cloudinary')
const cloudinaryStorage = require('multer-storage-cloudinary')
const baseAccountUrl = 'http://localhost:' + portNumber + '/accounts/'
const auth = require('../middleware/auth')
const md5 = require('md5')
const jwt = require('jsonwebtoken')
const jwtSecretString = utils.jwtSecretString
const cloudinaryConfig = require('../services/utils')
const subDeleteRoute = require('../middleware/sub-delete-route')

cloudinary.config(cloudinaryConfig.cloudinaryConfig)

const storage = cloudinaryStorage({
    cloudinary : cloudinary,
    folder : 'dms/accounts'
})

const upload = multer({
    storage: storage
})


/* <-------------------------------------------------GET_ALL******----------------------------------------> */


/* GET ROUTE - ALL ACCOUNTS*/
router.get('/', (req, res, next) => {
    Account
        .find()
        .select('-__v -password -_id')
        .exec()
        .then(docs => {
            const getAllAccountsResponse = {
                resStatus : 200,
                count: docs.length,
                accounts: docs.map(doc => {
                    return {
                        account: doc,
                        requests: {
                            type: 'GET',
                            url: baseAccountUrl + doc.regNumber
                        }
                    }
                })
            }
            res.status(200).json(getAllAccountsResponse)
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})


/* <-------------------------------------------------GET******----------------------------------------> */

/* GET ROUTE - SINGLE ACCOUNT */
router.get('/:registrationNumber', (req, res, next) => {
    const registrationNumber = req.params.registrationNumber
    Account
        .find({
            regNumber: registrationNumber
        })
        .select('-__v -password -_id')
        .exec()
        .then(doc => {
            if (doc.length < 1) {
                res.status(404).json({
                    resStatus : 404,
                    message: 'no entry found'
                })
            } 
            res.status(200).json({
                resStatus : 200,
                account: doc,
                requests: 'GET',
                url: baseAccountUrl
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------DELETE******----------------------------------------> */


/* DELETE ROUTE */
router.delete('/:registrationNumber', subDeleteRoute, (req, res, next) => {
    const registrationNumber = req.params.registrationNumber

    Account
        .remove({
            regNumber: registrationNumber
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'account deleted',
                result: result,
                request: {
                    type: 'GET',
                    url: baseAccountUrl
                }
            })
        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})

/* <-------------------------------------------------PATCH******----------------------------------------> */


/* PATCH ROUTE */
router.patch('/:regNumber', (req, res, next) => {
    const regNumber = req.params.regNumber

    const updateTo = {}

    for (const entry of req.body) {
        updateTo[entry.propertyName] = entry.value
    }

    console.log(updateTo)

    Account
        .update({
            regNumber: regNumber
        }, {
            $set: updateTo
        })
        .exec()
        .then(result => {
            res.status(201).json({
                message: 'account updated',
                result: result,
                requests: {
                    type: 'GET',
                    url: baseAccountUrl + regNumber
                }
            })
        })
        .catch(error => {
            console.log(error)
            res.status(500).json(defaultError())
        })
})

/* <-------------------------------------------------******----------------------------------------> */

/* <-------------------------------------------------SIGNUP******----------------------------------------> */

router.post('/create-account', (req, res, next) => {
 
    Account
        .find({regNumber : req.body.regNumber})
        .exec()
        .then(result => {
            if(result.length > 0){
                res.status(409).json({
                    resStatus : 409,
                    message : `account ${req.body.regNumber} existis`
                })
            }else {
                const account = new Account({
                    _id: new mongoose.Types.ObjectId(),
                    firstName: req.body.firstName,
                    lastName: req.body.lastName,
                    email: req.body.email,
                    course: req.body.course,
                    college : req.body.college,
                    regNumber: req.body.regNumber,
                    admissionYear: req.body.admissionYear,
                    department: req.body.department,
                    admissionStatus: req.body.admissionStatus,
                    studentAvatar: req.body.studentAvatar,
                    informationCompletionStatus: req.body.informationCompletionStatus,
                    password: md5(req.body.password)
                })
                console.log(account)
                account
                    .save()
                    .then(result => {
                        res.status(201).json({
                            resStatus : 201,
                            message: `account ${account.regNumber} created`
                        })
                    })
                    .catch(error => {
                        res.status(500).json(defaultError(error))
                    })
            }
        })
})


/* <-------------------------------------------------LOGIN******----------------------------------------> */

router.post('/login', (req, res, next) => {

    const email = req.body.email

    Account.find({
            email: email
        })
        .select('-__v')
        .exec()
        .then(account => {

            if (account.length < 1) {
                return res.status(401).json({
                    message: 'authentication failed'
                })
            }

            const clearPassword = req.body.password
            const hashedPassword = md5(clearPassword)
            console.log(account[0].password)
            console.log(hashedPassword)
            if (account[0].password !== hashedPassword) {
                return res.status(401).json({
                    message: 'authenticaton failed : check password'
                })
            } else {
                const token = jwt.sign({
                        email: account[0].email,
                        registrationNumber: account[0].registrationNumber,
                    },
                    jwtSecretString, {
                        expiresIn: '1h'
                    })

                return res.status(200).json({
                    message: 'authentication successful',
                    token: token,
                    _id : account[0]._id,
                    firstName : account[0].firstName,
                    lastName: account[0].lastName,
                    email: account[0].email,
                    course: account[0].course,
                    college : account[0].college,
                    regNumber: account[0].regNumber,
                    admissionYear: account[0].admissionYear,
                    department: account[0].department,
                    admissionStatus: account[0].admissionStatus,
                    studentAvatar: account[0].studentAvatar,
                    informationCompletionStatus: account[0].informationCompletionStatus,
                })
            }

        })
        .catch(error => {
            res.status(500).json(defaultError(error))
        })
})


module.exports = router