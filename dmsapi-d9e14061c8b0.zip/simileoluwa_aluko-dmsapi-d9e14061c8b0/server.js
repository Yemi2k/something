'use strict'

const http = require('http')
const app = require('./app')
const portNumber = require('./api/services/utils').port
const port = process.env.port || portNumber
const server = http.createServer(app)
server.listen(port)