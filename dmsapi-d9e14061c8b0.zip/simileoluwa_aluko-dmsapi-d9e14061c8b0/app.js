const express = require('express')
const app = express()
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const cors = require('cors')
const morgan = require('morgan')

//import routes
const accountRoute = require('./api/routes/account')
const jambRoute = require('./api/routes/jamb')
const studentRoute = require('./api/routes/student')
const waecRoute = require('./api/routes/waec')

mongoose.connect(
//mongodb connection string
,
{ useNewUrlParser: true }, error => {
    if(error) {
        console.log('unable to connect to the server, Error :', error)
    }else {
        console.log('connected to the server successfully.')
    }
})

mongoose.Promise = global.Promise
app.use('/uploads', express.static('uploads'))
app.use(cors())
app.use(morgan('dev'))
app.use(bodyParser.urlencoded({extended : false}))
app.use(bodyParser.json())

// handling route requests
app.use('/accounts', accountRoute)
app.use('/jamb', jambRoute)
app.use('/students', studentRoute)
app.use('/waec', waecRoute)

app.use( (req, res, next) => {
    const error = new Error('request not found')
    error.status = 404
    next(error)
})

app.use((error, req, res, next) => {
    res.status(error.status || 500)
    res.json({
        error : {
            message : error.message 
        }
    })
})
module.exports = app